This module provides an advanced Entity Reference widget that uses a view for selecting items.
The view can be paginated and have exposed filters.
It requires javascript to be enabled.

Usage:
1) Add the display "Entityreference View Widget" to your view.
2) Add "Entity Reference View Widget Checkbox" among the fields.
3) In the Field UI for the Entity Reference field select "View" as the widget
and on the next page select your View from the dropdown.
