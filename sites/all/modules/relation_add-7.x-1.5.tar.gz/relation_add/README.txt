Relation add widget.
